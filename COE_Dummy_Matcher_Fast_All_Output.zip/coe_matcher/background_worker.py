"""Background reconciliation worker for Streamlit Cloud."""
import argparse, json, os, pickle, time, traceback
from .pipeline import run_reconciliation


def write_status(path, **kw):
    tmp = path + '.tmp'
    data = dict(kw)
    data['updated'] = time.time()
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--val', required=True)
    ap.add_argument('--day', required=True)
    ap.add_argument('--index', default='')
    ap.add_argument('--workdir', required=True)
    ap.add_argument('--excluded', default='')
    ap.add_argument('--processes', type=int, default=1)
    ap.add_argument('--status', required=True)
    ap.add_argument('--result', required=True)
    args = ap.parse_args()
    write_status(args.status, state='RUNNING', progress=0.0, message='Starting background reconciliation')
    def progress(message, fraction):
        write_status(args.status, state='RUNNING', progress=float(fraction), message=str(message))
    try:
        excluded = [x.strip().upper() for x in args.excluded.split(',') if x.strip()]
        run = run_reconciliation(args.val, args.day, args.index, args.workdir, excluded=excluded,
                                 processes=max(1, int(args.processes)), progress=progress)
        with open(args.result, 'wb') as f:
            pickle.dump(run, f, protocol=pickle.HIGHEST_PROTOCOL)
        write_status(args.status, state='DONE', progress=1.0, message='Reconciliation finished')
    except Exception as e:
        tb = traceback.format_exc()
        with open(os.path.join(args.workdir, 'coe_processing_traceback.txt'), 'w', encoding='utf-8') as f:
            f.write(tb)
        write_status(args.status, state='ERROR', progress=0.0, message=f'{type(e).__name__}: {e}', traceback=tb)
        raise


if __name__ == '__main__':
    main()
