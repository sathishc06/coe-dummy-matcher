# Diagnostic mode

This build keeps the Streamlit page alive when reconciliation raises an exception and displays the full Python traceback.

For troubleshooting only. Do not treat a run that reports `Processing error` as an official output. Keep Worker processes at 1 while diagnosing.
